// KHR platform header
